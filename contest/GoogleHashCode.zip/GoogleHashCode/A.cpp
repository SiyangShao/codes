#include <bits/stdc++.h>
using namespace std;
int main() {
	int C, P;
	cin >> C >> P;
	if (C == 3 && P == 3) {
		cout << "3\nWebServer\n Bob Anna\n Logging\n Anna\n WebChat\n Maria "
				"Bob\n ";
	}
}